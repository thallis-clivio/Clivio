import { useParams, Link, useLocation } from "wouter";
import {
  useGetCreative, getGetCreativeQueryKey,
  useDeleteCreative, useAnalyzeCreative,
  useGetCreativeChart, getGetCreativeChartQueryKey,
  getListCreativesQueryKey, getGetDashboardSummaryQueryKey,
  getGetPerformanceSummaryQueryKey, getGetDashboardChartsQueryKey,
} from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatRoas, formatDate } from "@/lib/format";
import { ArrowLeft, Trash2, Edit, BrainCircuit, LineChart as LineIcon, AlertTriangle, Gauge, TrendingDown, Activity, Rocket, Ban } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CreativeForm } from "@/components/creative-form";
import { useState, useMemo } from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer,
} from "recharts";

type DateFilter = "all" | "daily" | "weekly" | "monthly";

const DATE_FILTER_LABELS: Record<DateFilter, string> = {
  all: "Tudo",
  daily: "Hoje",
  weekly: "Semana",
  monthly: "Mês",
};

function getDecisionColor(decision: string, monitorarReason?: string | null) {
  switch (decision) {
    case "ESCALAR": return "bg-green-500/20 text-green-500 border-green-500/30";
    case "MONITORAR":
      return monitorarReason === "decaindo"
        ? "bg-orange-500/20 text-orange-400 border-orange-500/30"
        : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
    case "PAUSAR": return "bg-red-500/20 text-red-500 border-red-500/30";
    default: return "bg-gray-500/20 text-gray-500 border-gray-500/30";
  }
}

function getPausarLabel(reason?: string | null) {
  if (reason === "semVendas") return "Sem Vendas";
  if (reason === "prejuizo") return "Prejuízo";
  return null;
}

function getPredictabilityColor(label: string) {
  if (label === "EXCELENTE") return "bg-green-500/20 text-green-400 border-green-500/30";
  if (label === "BOM") return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
  return "bg-red-500/20 text-red-400 border-red-500/30";
}

function getCpaColor(cpa: number, totalSales: number) {
  if (totalSales === 0) return "text-muted-foreground";
  if (cpa < 150) return "text-green-400";
  if (cpa < 300) return "text-yellow-400";
  return "text-red-400";
}

export default function CreativeDetail() {
  const { id } = useParams<{ id: string }>();
  const creativeId = parseInt(id || "0", 10);
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [chartDateFilter, setChartDateFilter] = useState<DateFilter>("all");

  const { data: creative, isLoading } = useGetCreative(creativeId, {
    query: { queryKey: getGetCreativeQueryKey(creativeId), enabled: !!creativeId }
  });

  const chartParams = useMemo(() => ({ dateFilter: chartDateFilter }), [chartDateFilter]);
  const { data: chartData, isLoading: isChartLoading } = useGetCreativeChart(creativeId, chartParams, {
    query: { queryKey: getGetCreativeChartQueryKey(creativeId, chartParams), enabled: !!creativeId }
  });

  const formattedChartData = useMemo(() => {
    if (!chartData) return [];
    return chartData.map(d => ({ ...d, dateLabel: formatDate(d.date) }));
  }, [chartData]);

  const deleteCreative = useDeleteCreative();
  const analyzeCreative = useAnalyzeCreative();

  function invalidateAll() {
    queryClient.invalidateQueries({ queryKey: getListCreativesQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetPerformanceSummaryQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardChartsQueryKey() });
  }

  const handleDelete = () => {
    if (confirm("Tem certeza que deseja excluir este criativo?")) {
      deleteCreative.mutate({ id: creativeId }, {
        onSuccess: () => {
          toast({ title: "Criativo excluído" });
          invalidateAll();
          setLocation("/");
        },
        onError: () => toast({ title: "Erro ao excluir", variant: "destructive" })
      });
    }
  };

  const handleAnalyze = () => {
    analyzeCreative.mutate({ id: creativeId }, {
      onSuccess: () => toast({ title: "Análise concluída" }),
      onError: () => toast({ title: "Falha na análise", variant: "destructive" })
    });
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="p-6 space-y-6">
          <Skeleton className="h-10 w-64" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Skeleton className="h-[400px]" />
            <Skeleton className="h-[400px] md:col-span-2" />
          </div>
        </div>
      </Layout>
    );
  }

  if (!creative) {
    return (
      <Layout>
        <div className="p-6 flex flex-col items-center justify-center min-h-[50vh]">
          <h2 className="text-2xl font-bold mb-4">Criativo não encontrado</h2>
          <Link href="/"><Button>Voltar ao Painel</Button></Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex-1 p-6 space-y-6">

        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="icon" className="shrink-0" data-testid="button-back">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-3xl font-bold tracking-tight" data-testid="text-creative-name">{creative.name}</h2>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <span className="text-muted-foreground text-sm">{formatDate(creative.date)}</span>
                <div className="flex flex-col gap-0.5">
                  <Badge variant="outline" className={`font-mono border text-xs inline-flex items-center gap-1 ${getDecisionColor(creative.decision, creative.monitorarReason)}`} data-testid="badge-decision">
                    {creative.decision === "ESCALAR" && <Rocket className="w-3 h-3" />}
                    {creative.decision === "MONITORAR" && (
                      creative.monitorarReason === "decaindo"
                        ? <TrendingDown className="w-3 h-3" />
                        : <Activity className="w-3 h-3" />
                    )}
                    {creative.decision === "PAUSAR" && (
                      creative.pausarReason === "semVendas"
                        ? <Ban className="w-3 h-3" />
                        : <TrendingDown className="w-3 h-3" />
                    )}
                    {creative.decision}
                  </Badge>
                  {creative.decision === "ESCALAR" && (
                    <span className="flex items-center gap-0.5 text-[10px] font-semibold text-green-400">
                      <Rocket className="w-2.5 h-2.5" />
                      Acelerando
                    </span>
                  )}
                  {creative.decision === "MONITORAR" && creative.monitorarReason && (
                    <span className={`flex items-center gap-0.5 text-[10px] font-semibold ${creative.monitorarReason === "decaindo" ? "text-orange-400" : "text-yellow-400"}`}>
                      {creative.monitorarReason === "decaindo"
                        ? <TrendingDown className="w-2.5 h-2.5" />
                        : <Activity className="w-2.5 h-2.5" />
                      }
                      {creative.monitorarReason === "decaindo" ? "Decaindo" : "Lucrativo"}
                    </span>
                  )}
                  {creative.decision === "PAUSAR" && (
                    <span className="flex items-center gap-0.5 text-[10px] font-semibold text-red-400">
                      {creative.pausarReason === "semVendas"
                        ? <Ban className="w-2.5 h-2.5" />
                        : <TrendingDown className="w-2.5 h-2.5" />
                      }
                      {getPausarLabel(creative.pausarReason)}
                    </span>
                  )}
                </div>
                <Badge variant="outline" className={`border text-xs ${getPredictabilityColor(creative.predictabilityLabel)}`} data-testid="badge-predictability">
                  {creative.predictabilityLabel}
                </Badge>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2" onClick={handleAnalyze} disabled={analyzeCreative.isPending} data-testid="button-analyze">
              <BrainCircuit className={`w-4 h-4 ${analyzeCreative.isPending ? "animate-pulse text-primary" : ""}`} />
              {analyzeCreative.isPending ? "Analisando..." : "Analisar Criativo"}
            </Button>
            <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon" data-testid="button-edit"><Edit className="w-4 h-4" /></Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px] border-border">
                <DialogHeader><DialogTitle>Editar Criativo</DialogTitle></DialogHeader>
                <CreativeForm initialData={creative} onSuccess={() => { setIsEditOpen(false); queryClient.invalidateQueries({ queryKey: getGetCreativeQueryKey(creativeId) }); invalidateAll(); }} />
              </DialogContent>
            </Dialog>
            <Button variant="destructive" size="icon" onClick={handleDelete} disabled={deleteCreative.isPending} data-testid="button-delete">
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* AI Analysis */}
        {analyzeCreative.data && (
          <Alert className="border-primary bg-primary/5" data-testid="alert-analysis">
            <BrainCircuit className="h-5 w-5 text-primary" />
            <AlertTitle className="font-bold tracking-widest uppercase text-primary">Relatório de Inteligência</AlertTitle>
            <AlertDescription className="mt-2 space-y-3">
              <div className="space-y-2">
                {analyzeCreative.data.explanation.split("\n\n").map((block, bi) => (
                  <div key={bi}>
                    {block.split("\n").map((line, li) => {
                      const isMath = line.startsWith("Comissão:") || line.startsWith("ROAS") || line.startsWith("CPA");
                      return isMath ? (
                        <div key={li} className="font-mono text-xs bg-background/60 border border-border/60 rounded px-2 py-1 mt-1 text-foreground/90 leading-relaxed">
                          {line}
                        </div>
                      ) : (
                        <p key={li} className="text-foreground text-sm leading-relaxed">{line}</p>
                      );
                    })}
                  </div>
                ))}
              </div>
              <div className="bg-background/50 p-3 rounded-md border border-border">
                <strong className="block text-xs uppercase tracking-wider text-muted-foreground mb-1">Ação Recomendada</strong>
                <span className="text-sm">{analyzeCreative.data.nextAction}</span>
              </div>
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* KPI Column */}
          <div className="space-y-4">
            <Card className="border-border/50 bg-card/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-widest">Desempenho</CardTitle>
              </CardHeader>
              <CardContent className="space-y-5">
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">ROAS</div>
                  <div className="text-4xl font-bold tabular-nums text-primary" data-testid="text-roas">{formatRoas(creative.roas)}</div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-xs text-muted-foreground mb-0.5">Gasto</div>
                    <div className="text-lg font-bold tabular-nums" data-testid="text-spend">{formatCurrency(creative.spend)}</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-0.5">Comissão</div>
                    <div className="text-lg font-bold tabular-nums" data-testid="text-commission">{formatCurrency(creative.commission)}</div>
                  </div>
                </div>
                <div className="h-px bg-border" />
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-xs text-muted-foreground mb-0.5">Total Vendas</div>
                    <div className="text-lg font-bold tabular-nums">{creative.totalSales}</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-0.5">CPA</div>
                    <div className={`text-lg font-bold tabular-nums ${getCpaColor(creative.cpa, creative.totalSales)}`} data-testid="text-cpa">
                      {creative.totalSales === 0 ? "—" : formatCurrency(creative.cpa)}
                    </div>
                  </div>
                </div>
                <div className="h-px bg-border" />
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">Dias sem Venda</div>
                  <div className={`text-base font-semibold tabular-nums ${creative.daysWithoutSales >= 2 ? "text-red-400" : creative.daysWithoutSales === 1 ? "text-yellow-400" : "text-green-400"}`}>
                    {creative.daysWithoutSales}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Predictability Card */}
            <Card className="border-border/50 bg-card/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <Gauge className="w-3.5 h-3.5" />
                  Desempenho
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-sm font-semibold ${getPredictabilityColor(creative.predictabilityLabel).includes("green") ? "text-green-400" : getPredictabilityColor(creative.predictabilityLabel).includes("yellow") ? "text-yellow-400" : "text-red-400"}`}>
                    {creative.predictabilityLabel}
                  </span>
                  <span className="text-2xl font-bold tabular-nums">{creative.predictabilityScore}<span className="text-sm text-muted-foreground">/100</span></span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${creative.predictabilityScore > 80 ? "bg-green-500" : creative.predictabilityScore >= 50 ? "bg-yellow-500" : "bg-red-500"}`}
                    style={{ width: `${creative.predictabilityScore}%` }}
                  />
                </div>
              </CardContent>
            </Card>

            {creative.daysWithoutSales > 0 && (
              <Alert className="border-orange-500/50 bg-orange-500/10 text-orange-500">
                <AlertTriangle className="h-4 w-4 stroke-orange-500" />
                <AlertTitle>Atenção</AlertTitle>
                <AlertDescription>
                  Este criativo está sem vendas há <strong>{creative.daysWithoutSales} dia(s)</strong>.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Sales Over Time + Breakdown */}
          <div className="md:col-span-2 space-y-4">

            {/* Sales chart card */}
            <Card className="border-border/50 bg-card/50">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-widest">
                    Vendas por Dia (este criativo)
                  </CardTitle>
                  <div className="flex rounded-md border border-border overflow-hidden">
                    {(["all", "daily", "weekly", "monthly"] as DateFilter[]).map(f => (
                      <button
                        key={f}
                        onClick={() => setChartDateFilter(f)}
                        className={`px-3 py-1 text-xs font-medium transition-colors ${
                          chartDateFilter === f
                            ? "bg-primary text-primary-foreground"
                            : "text-muted-foreground hover:text-foreground hover:bg-muted"
                        }`}
                      >
                        {DATE_FILTER_LABELS[f]}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] w-full">
                  {isChartLoading ? (
                    <Skeleton className="w-full h-full" />
                  ) : formattedChartData.length === 0 ? (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground text-sm">
                      Nenhum dado para o período selecionado.
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={formattedChartData} margin={{ top: 5, right: 10, left: 10, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                        <XAxis dataKey="dateLabel" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} dy={8} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                        <Tooltip
                          contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--popover-foreground))' }}
                          formatter={(v: number) => [v, "Vendas"]}
                          labelFormatter={label => `Data: ${label}`}
                        />
                        <Line
                          dataKey="totalSales"
                          stroke="hsl(142 71% 45%)"
                          strokeWidth={2.5}
                          dot={{ fill: "hsl(142 71% 45%)", r: 4, strokeWidth: 0 }}
                          activeDot={{ r: 6, strokeWidth: 0 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Sales by plan */}
            <Card className="border-border/50 bg-card/50">
            <CardHeader className="pb-4 border-b border-border">
              <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                <LineIcon className="w-4 h-4" />
                Vendas por Plano
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {(
                  [
                    { label: "Plano 5m", value: creative.sales5m, rate: "R$217" },
                    { label: "Plano 7m", value: creative.sales7m, rate: "R$300" },
                    { label: "Plano 9m", value: creative.sales9m, rate: "R$380" },
                    { label: "Plano 12m", value: creative.sales12m, rate: "R$460" },
                    { label: "Plano 16m", value: creative.sales16m, rate: "R$520" },
                    { label: "Plano 20m", value: creative.sales20m, rate: "R$650" },
                  ]
                ).map(plan => (
                  <div key={plan.label} className="bg-background p-4 rounded-lg border border-border">
                    <div className="text-xs text-muted-foreground mb-2">{plan.label}</div>
                    <div className="flex items-end justify-between">
                      <div className="text-3xl font-bold tabular-nums">{plan.value}</div>
                      <div className="text-xs text-muted-foreground pb-1">@ {plan.rate}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 rounded-lg border border-border bg-background/50">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Total de Vendas</span>
                  <span className="text-xl font-bold tabular-nums">{creative.totalSales}</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-sm text-muted-foreground">CPA (Custo por Aquisição)</span>
                  <span className={`text-xl font-bold tabular-nums ${getCpaColor(creative.cpa, creative.totalSales)}`}>
                    {creative.totalSales === 0 ? "—" : formatCurrency(creative.cpa)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </Layout>
  );
}
